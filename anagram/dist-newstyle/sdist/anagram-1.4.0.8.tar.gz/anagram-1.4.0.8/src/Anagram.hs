module Anagram (anagramsFor) where

import Data.MultiSet (MultiSet)
import qualified Data.MultiSet as MultiSet

import Data.Text (Text)
import qualified Data.Text as T

anagramsFor :: String -> [String] -> [String]
anagramsFor xs xss = []
